package com.cg.quiz.service;
/*********************************
 * Author="ManishaReddy"
 * page="ServiceClass"
 * Description="contains all serviceClass Implementations"
 * published Date=9-2-2017
 */
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.quiz.dao.QuizDao;
import com.cg.quiz.entities.Quiz;
@Service
@Transactional
public class QuizServiceImpl implements QuizService {
	@Autowired
	QuizDao dao;
	@Override
	public int addQuizDetails(Quiz quiz) {
		// TODO Auto-generated method stub
		return dao.addQuizDetails(quiz);
	}

}
