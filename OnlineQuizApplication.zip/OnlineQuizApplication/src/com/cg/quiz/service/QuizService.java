package com.cg.quiz.service;
/*********************************
 * Author="ManishaReddy"
 * page="ServiceInterface"
 * Description="contains serviceInterface method"
 * published Date=9-2-2017
 */
import com.cg.quiz.entities.Quiz;

public interface QuizService {
public int addQuizDetails(Quiz quiz);
}
