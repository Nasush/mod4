package com.cg.quiz.controller;
/*********************************
 * Author="ManishaReddy"
 * page="ApplicationController"
 * Description="contains all annotations and add functionalities"
 * published Date=9-2-2017
 */
import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.quiz.entities.Quiz;
import com.cg.quiz.service.QuizService;

@Controller
public class QuizController 
{
	@Autowired
	QuizService service;
@RequestMapping("/addques")
public String addQues(Model model)
{
	Quiz quiz=new Quiz();
	model.addAttribute("add",quiz);
	return "AddQuestion";
	
}
@ModelAttribute("sme")
public Map<String,String> map(){
	Map<String,String> sme=new HashMap<String,String>();
	sme.put("MATHS","MATHS");
	sme.put("HISTORY","HISTORY");
	sme.put("SCIENCE","SCIENCE");
	return sme;
}
@RequestMapping("/addquestion")
public String addQuestion(@Valid @ModelAttribute("add")Quiz quiz,BindingResult result,Model model)
{
	if(result.hasErrors()){
		
		return "adddetails"; 
	}
	int quesno=service.addQuizDetails(quiz);
	model.addAttribute("add",quesno);
	return "success";
}
}
