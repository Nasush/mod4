package com.cg.quiz.dao;
/*********************************
 * Author="ManishaReddy"
 * page="DaoInterface"
 * Description="Dao addition"
 * published Date=9-2-2017
 */
import com.cg.quiz.entities.Quiz;

public interface QuizDao {
	public int addQuizDetails(Quiz quiz);
}
