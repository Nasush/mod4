package com.cg.quiz.dao;
/*********************************
 * Author="ManishaReddy"
 * page="DaoClass"
 * Description="Dao class Implementation"
 * published Date=9-2-2017
 */
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.quiz.entities.Quiz;
@Repository
public class QuizDaoImpl implements QuizDao {
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public int addQuizDetails(Quiz quiz) {
		entitymanager.persist(quiz);
		entitymanager.flush();
		return quiz.getQuesNo();
	}

}
