package com.cg.customer.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.customer.entities.Customer;
import com.cg.customer.service.CustomerService;

@Controller
public class CustomerController {
@Autowired
CustomerService service;
@RequestMapping("/insert")
public String insert(Model model)
{
	Customer cust=new Customer();
	model.addAttribute("inset",cust);
	return "AddCustomer";
}
@RequestMapping("/EnterAddpage")
public String enterAddpage(@RequestParam("category")String str, @ModelAttribute("inset")Customer customer,Model model)
{
	String a="OnlineBanking";
	String b="GeneralBanking";
	String c="Other";
	if(str.equals(a)){
		customer.setPriority("High");
		customer.setStatus("Open");
		int id=service.addCustomerDetails(customer);
		model.addAttribute("complaintId",id);
	}
	else if(str.equals(b)){
		customer.setPriority("Medium");
		customer.setStatus("Open");
		int id=service.addCustomerDetails(customer);
		model.addAttribute("complaintId",id);
	}else if(str.equals(c)){
		customer.setPriority("Low");
		customer.setStatus("Open");
		int id=service.addCustomerDetails(customer);
		model.addAttribute("complaintId",id);
	}
return "success";
}
@RequestMapping("/checkStatus")
public String checkStatus(Model model){
	Customer cust=new Customer();
	model.addAttribute("single",cust);
	return "checkStatusDetails";
}
@RequestMapping("/checkStatuspage")
public String checkStatuspage(@ModelAttribute("single")Customer customer,Model model){
	Customer record=service.retrieveSingleRecord(customer);
	model.addAttribute("singleList",record);
	return "singleRecord";
}
@RequestMapping("/showall")
public String showAll(Model model){
	ArrayList<Customer> list=service.viewCustomerList();
	model.addAttribute("CustomerList",list);
	return "ViewAll";
}
}
