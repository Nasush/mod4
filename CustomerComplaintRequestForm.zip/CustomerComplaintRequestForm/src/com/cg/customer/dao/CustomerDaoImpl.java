package com.cg.customer.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.customer.entities.Customer;
@Repository
public class CustomerDaoImpl implements CustomerDao {
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public int addCustomerDetails(Customer cust) {
		entityManager.persist(cust);
		entityManager.flush();
		return cust.getComplaintId();
	}
	@Override
	public Customer retrieveSingleRecord(Customer customer) {
		Customer record=entityManager.find(Customer.class,customer.getComplaintId());
		return record;
	}
	@Override
	public ArrayList<Customer> viewCustomerList() {
		ArrayList<Customer> list;
		String query="select h from hibernate h";
		TypedQuery<Customer> qry=entityManager.createQuery(query,Customer.class);
		list=(ArrayList<Customer>) qry.getResultList();
		return list;
	}

}
