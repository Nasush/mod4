package com.cg.customer.dao;

import java.util.ArrayList;

import com.cg.customer.entities.Customer;

public interface CustomerDao {
	public int addCustomerDetails(Customer cust);
	public Customer retrieveSingleRecord(Customer customer);
	public ArrayList<Customer> viewCustomerList();
}
