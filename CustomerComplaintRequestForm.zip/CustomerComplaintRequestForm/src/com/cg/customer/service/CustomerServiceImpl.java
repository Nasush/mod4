package com.cg.customer.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.customer.dao.CustomerDao;
import com.cg.customer.entities.Customer;
@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao dao;
	@Override
	public int addCustomerDetails(Customer cust) {
		// TODO Auto-generated method stub
		return dao.addCustomerDetails(cust);
	}
	@Override
	public Customer retrieveSingleRecord(Customer customer) {
		// TODO Auto-generated method stub
		return dao.retrieveSingleRecord(customer);
	}
	@Override
	public ArrayList<Customer> viewCustomerList() {
		// TODO Auto-generated method stub
		return dao.viewCustomerList();
	}

}
