package com.cg.customer.service;

import java.util.ArrayList;

import com.cg.customer.entities.Customer;
public interface CustomerService {
	public int addCustomerDetails(Customer cust);
	public Customer retrieveSingleRecord(Customer customer);
	public ArrayList<Customer> viewCustomerList();
}
