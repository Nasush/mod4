package com.cg.customer.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="hibernate")
@SequenceGenerator(name="myseq",sequenceName="cust_seq")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
private int complaintId;
	@Column(name="customer_Id")
	private int customerId;
private String branchcode;
private String mailId;
private String category;
private String description;
private String priority;
private String status;
public int getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}

public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getBranchcode() {
	return branchcode;
}
public void setBranchcode(String branchcode) {
	this.branchcode = branchcode;
}
public String getMailId() {
	return mailId;
}
public void setMailId(String mailId) {
	this.mailId = mailId;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getPriority() {
	return priority;
}
public void setPriority(String priority) {
	this.priority = priority;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
}
