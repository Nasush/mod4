package com.cg.share.Dao;

import com.cg.share.dto.Share;

public interface IShareDao {

	Share addshare(Share share);

}
