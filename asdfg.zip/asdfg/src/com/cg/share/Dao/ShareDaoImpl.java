package com.cg.share.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.share.dto.Share;

@Repository
public class ShareDaoImpl implements IShareDao {

	@PersistenceContext
	EntityManager em;
	@Override
	public Share addshare(Share share) {
		// TODO Auto-generated method stub
		em.persist(share);
		em.flush();
		return share;
	}

}
