package com.cg.share.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.share.dto.Share;
import com.cg.share.service.IShareService;


@Controller
public class sharecontroller {
	@Autowired
	IShareService service; 
	@RequestMapping("/Relaince")
	public String showpager(Model model)
	{
		Share share=new Share();
		share.setStock("relaince");
		share.setQuote(894.95);
		share.setAction("buy");
		model.addAttribute("share",share);
		return "reliancep";
		
	}
	@RequestMapping("calculate")
	public String amountrelaince(@ModelAttribute("share")Share sharea,Model model){
		int quantity=sharea.getQuantity();
		String action=sharea.getAction();
		if(action.equals("buy"))
		{
			sharea.setCommision(1.5);
		}
		else if (action.equals("sell")){
			sharea.setCommision(0.5);
			
		}
		double comm=sharea.getCommision();
		sharea.setAmount(comm*quantity);
		Share sharestored=service.addshare(sharea);
		model.addAttribute("dbshare",sharestored);
		return "order";
		
	}
	@RequestMapping("/Tata")
	public String showpaget(Model model)
	{
		Share share=new Share();
		share.setStock("Tata");
		share.setQuote(410.65);
		model.addAttribute("share",share);
		return "tatap";
		
	}
	@RequestMapping("/LNT")
	public String showpagetl(Model model)
	{
		Share share=new Share();
		share.setStock("Lnt");
		share.setQuote(1344.95);
		model.addAttribute("share",share);
		return "lntp";
		
	}
	

}
