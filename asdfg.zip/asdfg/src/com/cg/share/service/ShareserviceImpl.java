package com.cg.share.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.share.Dao.IShareDao;
import com.cg.share.dto.Share;

@Service
@Transactional
public class ShareserviceImpl implements IShareService {

	@Autowired
	IShareDao dao;
	@Override
	public Share addshare(Share share) {
		// TODO Auto-generated method stub
		return dao.addshare(share);
	}

}
