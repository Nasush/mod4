package com.cg.share.service;



import com.cg.share.dto.Share;

public interface IShareService {

	Share addshare(Share share);

}
