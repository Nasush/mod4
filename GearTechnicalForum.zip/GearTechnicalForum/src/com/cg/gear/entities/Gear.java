package com.cg.gear.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="query_master")
public class Gear {
	@Id
	@Column(name="query_id")
private int queryId;
private String technology;
@Column(name="query_raised_by")
private String queryraisedby;
private String query;
@NotEmpty(message="Solution can not be blank")

private String solutions;
@NotEmpty(message="Answered by can not be blank")

@Column(name="solution_given_by")
private String solutiongivenby;
public int getQueryId() {
	return queryId;
}
public void setQueryId(int queryId) {
	this.queryId = queryId;
}
public String getTechnology() {
	return technology;
}
public void setTechnology(String technology) {
	this.technology = technology;
}
public String getQueryraisedby() {
	return queryraisedby;
}
public void setQueryraisedby(String queryraisedby) {
	this.queryraisedby = queryraisedby;
}
public String getQuery() {
	return query;
}
public void setQuery(String query) {
	this.query = query;
}
public String getSolutions() {
	return solutions;
}
public void setSolutions(String solutions) {
	this.solutions = solutions;
}
public String getSolutiongivenby() {
	return solutiongivenby;
}
public void setSolutiongivenby(String solutiongivenby) {
	this.solutiongivenby = solutiongivenby;
}
}
