package com.cg.gear.controller;

import java.util.HashMap;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.gear.entities.Gear;
import com.cg.gear.service.GearService;

@Controller
public class GearController {
	@Autowired
	GearService service;
	@RequestMapping("/firstquerypage")
	public String firstQuerypage(Model model)
	{
	Gear gear=new Gear();
	model.addAttribute("update",gear);
	return "Update";
	}
	@RequestMapping("/EnterUpdatePage")
	public String enterUpdatepage(@ModelAttribute("update")Gear gear,Model model)
	{
		Gear modified=service.retrieveSingleRecord(gear);
		model.addAttribute("update1",modified);
		return "ViewUpdate";
	}
	@ModelAttribute("sme")
	public Map<String,String> map(){
		Map<String,String> sme=new HashMap<String,String>();
		sme.put("Uma","Uma");
		sme.put("Rahul","Rahul");
		sme.put("Kavit","Kavit");
		sme.put("Hema","Hema");
		return sme;
	}
	@RequestMapping("/EnterUpdatePage1")
	public String enterUpdatepage1(@Valid @ModelAttribute("update1")Gear gear,BindingResult result,Model model)
	{
		if(result.hasErrors()){
			
			return "ViewUpdate"; 
		}
		service.updateGearDetails(gear);
		model.addAttribute("update1",gear);
		return "success";
	}
}
