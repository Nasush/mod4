package com.cg.gear.service;

import com.cg.gear.entities.Gear;
public interface GearService {
	public void updateGearDetails(Gear gear);
	public Gear retrieveSingleRecord(Gear gear);
}
