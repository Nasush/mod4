package com.cg.gear.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.gear.dao.GearDao;
import com.cg.gear.entities.Gear;
@Service
@Transactional
public class GearServiceImpl implements GearService {
	@Autowired
	GearDao dao;
	@Override
	public void updateGearDetails(Gear gear) {
		// TODO Auto-generated method stub
		dao.updateGearDetails(gear);
	}
	@Override
	public Gear retrieveSingleRecord(Gear gear) {
		// TODO Auto-generated method stub
		return dao.retrieveSingleRecord(gear);
	}

}
