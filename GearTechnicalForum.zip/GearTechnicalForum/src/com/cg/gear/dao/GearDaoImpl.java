package com.cg.gear.dao;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.gear.entities.Gear;
@Repository
public class GearDaoImpl implements GearDao {
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public void updateGearDetails(Gear gear) {
		entityManager.merge(gear);
		entityManager.flush();// TODO Auto-generated method stub
		
	}
	@Override
	public Gear retrieveSingleRecord(Gear gear) {
		Gear record=entityManager.find(Gear.class,gear.getQueryId());
		return record;
	}

}
