package com.cg.gear.dao;

import com.cg.gear.entities.Gear;

public interface GearDao {
	public void updateGearDetails(Gear gear);
	public Gear retrieveSingleRecord(Gear gear);
}
